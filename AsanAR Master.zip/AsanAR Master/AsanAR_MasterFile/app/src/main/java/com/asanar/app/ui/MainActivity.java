﻿package com.asanar.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.asanar.app.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button homeBtn = findViewById(R.id.btnHome);
        Button cameraBtn = findViewById(R.id.btnCamera);

        homeBtn.setOnClickListener(v ->
                Toast.makeText(this, "Home tapped", Toast.LENGTH_SHORT).show()
        );

        cameraBtn.setOnClickListener(v ->
                startActivity(new Intent(this, CameraActivity.class))
        );
    }
}
