﻿package com.asanar.app.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Surface;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.asanar.app.R;
import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CameraActivity extends AppCompatActivity {

    private static final int REQ_CAMERA = 1001;

    private PreviewView previewView;
    private PoseAnalyzer poseAnalyzer;
    private ExecutorService analysisExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);

        previewView = findViewById(R.id.previewView);
        ImageButton back = findViewById(R.id.btnBack);
        back.setOnClickListener(v -> finish());

        analysisExecutor = Executors.newSingleThreadExecutor();
        poseAnalyzer = new PoseAnalyzer(this);

        if (hasCameraPermission()) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private boolean hasCameraPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture =
                ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();
                bindUseCases(cameraProvider);
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void bindUseCases(@NonNull ProcessCameraProvider cameraProvider) {
        Preview preview = new Preview.Builder()
                .build();

        CameraSelector selector = new CameraSelector.Builder()
                .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                .build();

        // ImageAnalysis for frames to PoseAnalyzer
        ImageAnalysis analysis = new ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                .build();

        analysis.setAnalyzer(analysisExecutor, (ImageProxy image) -> {
            try {
                ImageProxy.PlaneProxy[] planes = image.getPlanes();
                if (planes != null && planes.length == 3 && image.getImage() != null) {
                    byte[] nv21 = ImageUtils.yuv420888ToNv21(image.getImage());
                    int width = image.getWidth();
                    int height = image.getHeight();
                    int rotation = degreesFromRotation(image.getImageInfo().getRotationDegrees());
                    poseAnalyzer.analyze(nv21, width, height, rotation);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            } finally {
                image.close();
            }
        });

        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        cameraProvider.unbindAll();
        cameraProvider.bindToLifecycle(this, selector, preview, analysis);

        // Align target rotation with the display to minimize rotation corrections
        int displayRotation = previewView.getDisplay() != null
                ? previewView.getDisplay().getRotation() : Surface.ROTATION_0;
        preview.setTargetRotation(displayRotation);
        analysis.setTargetRotation(displayRotation);
    }

    private int degreesFromRotation(int rotationDegrees) {
        // ImageAnalysis already gives degrees; keep method in case we add mapping later.
        return rotationDegrees;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (poseAnalyzer != null) {
            poseAnalyzer.close();
        }
        if (analysisExecutor != null) {
            analysisExecutor.shutdown();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CAMERA) {
            if (hasCameraPermission()) {
                startCamera();
            } else {
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }
}
