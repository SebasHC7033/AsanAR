﻿package com.asanar.app.ui;

import android.media.Image;

import java.nio.ByteBuffer;

public final class ImageUtils {

    private ImageUtils() {}

    public static byte[] yuv420888ToNv21(Image image) {
        if (image.getFormat() != android.graphics.ImageFormat.YUV_420_888) {
            throw new IllegalArgumentException("Expected YUV_420_888");
        }
        Image.Plane[] planes = image.getPlanes();
        ByteBuffer yBuf = planes[0].getBuffer();
        ByteBuffer uBuf = planes[1].getBuffer();
        ByteBuffer vBuf = planes[2].getBuffer();

        int ySize = yBuf.remaining();
        int uSize = uBuf.remaining();
        int vSize = vBuf.remaining();

        // NV21 = Y + VU
        byte[] nv21 = new byte[ySize + uSize + vSize];
        yBuf.get(nv21, 0, ySize);

        // Interleave V and U (VU)
        byte[] uBytes = new byte[uSize];
        byte[] vBytes = new byte[vSize];
        uBuf.get(uBytes, 0, uSize);
        vBuf.get(vBytes, 0, vSize);

        int pos = ySize;
        for (int i = 0; i < vSize; i++) {
            nv21[pos++] = vBytes[i];
            if (i < uSize) {
                nv21[pos++] = uBytes[i];
            }
        }
        return nv21;
    }
}
