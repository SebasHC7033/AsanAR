﻿package com.asanar.app.ui;

import android.content.Context;
import android.util.Log;

public class PoseAnalyzer {
    private static final String TAG = "PoseAnalyzer";

    public PoseAnalyzer(Context context) {
        // TODO: load MP Tasks (e.g., Pose Landmarker) when you're ready
        Log.d(TAG, "PoseAnalyzer created (stub).");
    }

    public void analyze(byte[] frameNv21, int width, int height, int rotationDegrees) {
        // TODO: convert to the required format and run inference
        Log.d(TAG, "analyze() called (stub).");
    }

    public void close() {
        // TODO: release tasks/resources
        Log.d(TAG, "PoseAnalyzer closed (stub).");
    }
}
